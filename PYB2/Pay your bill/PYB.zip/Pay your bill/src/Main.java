import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Main {
	
	public static void main(String [] args) {
		
		Account J = new Account();
		
		J.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		J.setSize(700, 225);
		J.setVisible(true);
		
		/**Support s = new Support();**/
		
		
		
	}

}
